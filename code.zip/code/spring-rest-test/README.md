# Spring REST
# This project was made following an example from mkyong
Article link : https://www.mkyong.com/spring-boot/spring-rest-hello-world-example/

## 1. How to start
```
$ cd spring-rest-test

$ mvn clean install
$ mvn spring-boot:run

$ curl -v localhost:8080/users
```